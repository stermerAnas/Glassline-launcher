package com.glassline.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Violet = Color(0xFFB9A8FF)
private val Cyan = Color(0xFF8BE8E7)
private val Ink = Color(0xFF080A13)
private val Glass = Color(0x24FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlasslineApp() }
    }
}

data class LaunchableApp(val label: String, val packageName: String, val icon: Bitmap)

@Composable
private fun GlasslineApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("glassline", 0) }
    var allApps by remember { mutableStateOf(emptyList<LaunchableApp>()) }
    var hiddenPackages by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()) }
    var query by remember { mutableStateOf("") }
    var drawerOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var selectedApp by remember { mutableStateOf<LaunchableApp?>(null) }
    var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 6)) }
    var iconScale by remember { mutableFloatStateOf(prefs.getFloat("iconScale", 1f).coerceIn(.8f, 1.25f)) }

    fun loadApps() {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo.packageName
                try { LaunchableApp(info.loadLabel(pm).toString(), pkg, drawableToBitmap(info.loadIcon(pm))) }
                catch (_: Exception) { null }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }
    LaunchedEffect(Unit) { loadApps() }

    val visibleApps = allApps.filter { it.packageName !in hiddenPackages }
    val filteredApps = visibleApps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }

    BackHandler(drawerOpen || settingsOpen || selectedApp != null) {
        when { selectedApp != null -> selectedApp = null; settingsOpen -> settingsOpen = false; else -> { drawerOpen = false; query = "" } }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Color(0xFF141725), primary = Violet,
        secondary = Cyan, onBackground = Color(0xFFF4F3FF), onSurface = Color(0xFFF4F3FF)
    )) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize().background(
                Brush.linearGradient(listOf(Color(0xFF17152B), Color(0xFF080A13), Color(0xFF0B2028)))
            ).pointerInput(drawerOpen, settingsOpen) {
                var drag = 0f
                detectVerticalDragGestures(onVerticalDrag = { _, amount -> drag += amount }, onDragEnd = {
                    if (!drawerOpen && drag < -55f) drawerOpen = true
                    if (drawerOpen && drag > 75f) { drawerOpen = false; query = "" }
                    drag = 0f
                })
            }
        ) {
            // Decorative glows are static gradients, not continuously animated effects.
            Box(Modifier.offset(x = maxWidth * .56f, y = maxHeight * .08f).size(210.dp).background(
                Brush.radialGradient(listOf(Color(0x263F8DFF), Color.Transparent)), CircleShape))
            Box(Modifier.offset(x = (-70).dp, y = maxHeight * .42f).size(230.dp).background(
                Brush.radialGradient(listOf(Color(0x243EDECE), Color.Transparent)), CircleShape))

            AnimatedContent(
                targetState = drawerOpen,
                transitionSpec = { androidx.compose.animation.fadeIn(tween(160, easing = FastOutSlowInEasing)) togetherWith androidx.compose.animation.fadeOut(tween(100)) },
                label = "launcherScreen"
            ) { showDrawer ->
                if (showDrawer) {
                    DrawerScreen(
                        apps = filteredApps, query = query, onQuery = { query = it }, columns = columns,
                        iconScale = iconScale, onAppClick = { launchApp(context, it.packageName) },
                        onAppLongClick = { selectedApp = it }, onSettings = { settingsOpen = true },
                        onClose = { drawerOpen = false; query = "" }
                    )
                } else {
                    HomeScreen(
                        apps = visibleApps, iconScale = iconScale,
                        onOpenDrawer = { drawerOpen = true }, onSettings = { settingsOpen = true },
                        onAppClick = { launchApp(context, it.packageName) }, onAppLongClick = { selectedApp = it }
                    )
                }
            }

            if (settingsOpen) {
                SettingsDialog(columns, { columns = it; prefs.edit().putInt("columns", it).apply() }, iconScale,
                    { iconScale = it; prefs.edit().putFloat("iconScale", it).apply() }, onDismiss = { settingsOpen = false },
                    onSystemSettings = { context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
            }
            selectedApp?.let { app ->
                Dialog(onDismissRequest = { selectedApp = null }) {
                    Surface(shape = RoundedCornerShape(28.dp), color = Color(0xFF191C2B), tonalElevation = 8.dp) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(app.label, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("${app.packageName}", color = Color.LightGray, fontSize = 12.sp)
                            Button(onClick = {
                                val next = hiddenPackages.toMutableSet()
                                if (app.packageName in next) next.remove(app.packageName) else next.add(app.packageName)
                                hiddenPackages = next.toSet(); prefs.edit().putStringSet("hidden", hiddenPackages).apply(); selectedApp = null
                            }, modifier = Modifier.fillMaxWidth()) { Text(if (app.packageName in hiddenPackages) "Unhide app" else "Hide app") }
                            OutlinedButton(onClick = {
                                context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:${app.packageName}")))
                                selectedApp = null
                            }, modifier = Modifier.fillMaxWidth()) { Text("App info") }
                            TextButton(onClick = { selectedApp = null }, modifier = Modifier.align(Alignment.End)) { Text("Cancel") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    apps: List<LaunchableApp>, iconScale: Float, onOpenDrawer: () -> Unit, onSettings: () -> Unit,
    onAppClick: (LaunchableApp) -> Unit, onAppLongClick: (LaunchableApp) -> Unit
) {
    val context = LocalContext.current
    val clock = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val date = remember { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()) }
    var currentTime by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { currentTime = Date(); kotlinx.coroutines.delay(15_000) } }
    val favoriteNames = listOf("Phone", "Messages", "Chrome", "Camera")
    val favorites = favoriteNames.mapNotNull { name -> apps.firstOrNull { it.label.equals(name, true) } }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("GLASSLINE", fontSize = 11.sp, letterSpacing = 3.sp, color = Cyan, fontWeight = FontWeight.Bold)
                Text("Your space.", fontSize = 15.sp, color = Color(0xFFB9BDD0))
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White) }
        }
        Spacer(Modifier.height(36.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(Color(0x2CFFFFFF), Color(0x0DFFFFFF))))
            .padding(horizontal = 22.dp, vertical = 22.dp)) {
            Text(clock.format(currentTime), fontSize = 58.sp, fontWeight = FontWeight.Light, letterSpacing = (-2).sp, color = Color.White)
            Text(date.format(currentTime), fontSize = 14.sp, color = Color(0xFFC9CAD8))
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Widgets, null, tint = Cyan, modifier = Modifier.size(18.dp))
                Text("A little less noise.", color = Color(0xFFE5E4F5), fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth().clip(CircleShape).background(Glass).clickable(onClick = onOpenDrawer).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color(0xFFCFD1E1))
            Spacer(Modifier.width(10.dp)); Text("Search apps", color = Color(0xFFCFD1E1), modifier = Modifier.weight(1f))
            Text("↑", color = Cyan, fontSize = 18.sp)
        }
        Spacer(Modifier.weight(1f))
        if (favorites.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 12.dp, vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                favorites.take(5).forEach { app -> AppIcon(app, iconScale, onAppClick, onAppLongClick, showLabel = false, modifier = Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text("Swipe up for apps", color = Color(0xFF9FA4BC), fontSize = 12.sp)
            Spacer(Modifier.width(16.dp))
            Box(Modifier.width(36.dp).height(4.dp).clip(CircleShape).background(Color(0x66FFFFFF)))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DrawerScreen(
    apps: List<LaunchableApp>, query: String, onQuery: (String) -> Unit, columns: Int, iconScale: Float,
    onAppClick: (LaunchableApp) -> Unit, onAppLongClick: (LaunchableApp) -> Unit,
    onSettings: () -> Unit, onClose: () -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Applications", fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
                Text("${apps.size} apps", color = Color(0xFFAEB2C8), fontSize = 12.sp)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            TextButton(onClick = onClose) { Text("Done") }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(22.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Color(0x44FFFFFF), focusedContainerColor = Color(0x1AFFFFFF), unfocusedContainerColor = Color(0x14FFFFFF)))
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(apps, key = { it.packageName }) { app -> AppIcon(app, iconScale, onAppClick, onAppLongClick, showLabel = true, modifier = Modifier.fillMaxWidth()) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(app: LaunchableApp, scale: Float, onClick: (LaunchableApp) -> Unit, onLongClick: (LaunchableApp) -> Unit, showLabel: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).combinedClickable(onClick = { onClick(app) }, onLongClick = { onLongClick(app) }).padding(vertical = 2.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.foundation.Image(bitmap = app.icon.asImageBitmap(), contentDescription = app.label,
            modifier = Modifier.size((48 * scale).dp).clip(RoundedCornerShape((14 * scale).dp)))
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(app.label, fontSize = 11.sp, lineHeight = 13.sp, color = Color.White, textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(horizontal = 1.dp))
        }
    }
}

@Composable
private fun SettingsDialog(columns: Int, onColumns: (Int) -> Unit, iconScale: Float, onScale: (Float) -> Unit, onDismiss: () -> Unit, onSystemSettings: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth(.92f), shape = RoundedCornerShape(30.dp), color = Color(0xFF171A29)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Launcher settings", fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                Text("Grid columns: $columns", color = Color(0xFFD7D8E7))
                Slider(value = columns.toFloat(), onValueChange = { onColumns(it.toInt().coerceIn(3, 6)) }, valueRange = 3f..6f, steps = 2)
                Text("Icon size: ${(iconScale * 100).toInt()}%", color = Color(0xFFD7D8E7))
                Slider(value = iconScale, onValueChange = onScale, valueRange = .8f..1.25f)
                Text("More customization is planned; these controls are saved on this device.", color = Color(0xFF9FA4BC), fontSize = 12.sp)
                OutlinedButton(onClick = onSystemSettings, modifier = Modifier.fillMaxWidth()) { Text("Set default home app") }
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            }
        }
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

private fun drawableToBitmap(drawable: Drawable): Bitmap {
    val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(192)
    val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(192)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap
}
