# Glassline Launcher (prototype 0.1.0)

A lightweight, native Android launcher prototype designed around a futuristic dark-glass aesthetic for Samsung Galaxy A-series phones.

## Included in this prototype
- Android HOME intent so it can be selected as the default launcher.
- App list sourced from launchable activities; app icons are cached as bitmaps in the in-memory app list.
- Search by app label or package name.
- Long-press an app to hide/unhide it or open Android's app-info screen.
- Home screen with clean clock/date card, search shortcut, and a dock populated from common app names when available.
- System dark theme styling, subtle gradients, short screen transitions, vertical swipe gestures to open/close the drawer.
- Locally persisted grid column count and icon scale.
- No ads, analytics, or network permission.

## Important scope notes
This is a starter app, not yet a feature-complete replacement for One UI Home. Custom widgets, icon-pack loading, notification dots, real app-lock enforcement, folder editing, backup/restore, and true real-time blur are not implemented yet. The clock card is a native widget-like panel, not an Android AppWidget host. Android/Samsung controls some recents-screen, navigation, and gesture animations; a third-party launcher cannot guarantee Apple's exact animation behavior, particularly on Samsung's stock gesture stack. This prototype avoids continuous decorative animation and heavy blur to favor responsiveness.

## Build
- Android Studio Ladybug or newer recommended.
- JDK 17.
- Android SDK platform 35.
- Open this folder in Android Studio, allow Gradle sync, then Run on the A34.
- To install manually, build a debug APK in Android Studio (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).

The repository intentionally omits a Gradle wrapper binary. Android Studio can generate/use its configured Gradle installation.

## Device setup
1. Install the debug APK.
2. Open Settings and choose Apps > Choose default apps > Home app (wording varies by One UI version).
3. Select Glassline Launcher.
4. If a feature or gesture behaves differently on your One UI version, switch back to One UI Home in the same setting.

## Next implementation milestones
1. Add a real AppWidgetHost with widget picker and resize support.
2. Add icon pack support via standard icon-pack intents and caching.
3. Add editable folders, favorites/dock configuration, and backup/restore to a user-selected document.
4. Add notification dots only with an explicit, user-granted notification-listener permission and explain the privacy impact.
5. Add gesture customization and a settings screen with accessibility labels and reduced-motion option.
6. Test cold-start, scrolling, memory use, battery impact, and Samsung gesture behavior on the actual A34.
